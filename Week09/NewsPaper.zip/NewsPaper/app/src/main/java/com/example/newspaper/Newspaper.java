package com.example.newspaper;

public class Newspaper {

    private String newspaperName;
    private int newspaperImageId;

    public String getNewspaperName()
    {
        return  newspaperName;
    }
    public void setNewspaperName(String newspaperName)
    {
        this.newspaperName=newspaperName;
    }
    public int getImageid() { return newspaperImageId; }
    public void setImageid(int imageid) { newspaperImageId = imageid; }
}
